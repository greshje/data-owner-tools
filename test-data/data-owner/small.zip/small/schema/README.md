# Example clkhash schema files

This directory contains [clkhash schema files](https://clkhash.readthedocs.io/en/latest/schema.html). Each one of these files specify the fields that will be used in the hashing process as well as assigning weights to those fields for a particular run of the clkhash tool.

